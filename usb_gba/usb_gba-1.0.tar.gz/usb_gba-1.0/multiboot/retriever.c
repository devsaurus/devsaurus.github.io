/*
 *
 * Copyright (C) 2002, Arnim Laeuger
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version. See also the file COPYING which
 *  came with this application.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * $Id: retriever.c,v 1.6 2002/05/05 16:53:59 arnim Exp $
 *
 * $Log: retriever.c,v $
 * Revision 1.6  2002/05/05 16:53:59  arnim
 * + handle case 0x3e correctly in retrieve_4bytes()
 * + use macros instead of pointer variables for USB buffers
 *
 * Revision 1.5  2002/04/20 22:45:45  arnim
 * support double streamed transfers over OUT2 and OUT4
 *
 * Revision 1.4  2002/04/17 19:10:20  arnim
 * fix
 *
 * Revision 1.3  2002/04/17 19:04:14  arnim
 * adjust copyright
 *
 * Revision 1.2  2002/04/17 19:01:27  arnim
 * add header
 *
 */


#include <8051.h>
#include "ezusb_reg.h"

#include "dtypes.h"
#include "pagesize.h"

#define in0buf(n)  (&IN0BUF)[n]
#define out0buf(n) (&OUT0BUF)[n]
#define in2buf(n)  (&IN2BUF)[n]
#define out2buf(n) (&OUT2BUF)[n]
#define out4buf(n) (&OUT4BUF)[n]

extern UInt32 ClientLength;
extern UInt16 ClientPackets;
extern Byte   retr[4];


static data Byte pos_in_buf;
static bit requested_outx;
static bit use_out4;

static data Byte stream_toggle;

static Byte request_if_available()
{
   Byte err;

   /* do we still expect packets? */
   if (ClientPackets > 0) {
      /* do nothing if the packet has already been requested */
      if (!requested_outx) {
         if (use_out4)
            OUT4BC      = 0x00;  // arm endpoint OUT4
         else
            OUT2BC      = 0x00;  // arm endpoint OUT2

         requested_outx = TRUE;
         ClientPackets--;

         /* increment stream toggle counter
            we are now really finished with the old buffer */
         stream_toggle++;
         use_out4 = stream_toggle & TOGGLE_COUNT ? TRUE : FALSE;
      }
      err               = 0;
   } else {
      /* there is nothing left to do */
      requested_outx    = FALSE;
      err               = 1;
   }

   return(err);
}


void init_retriever()
{
   pos_in_buf     = 0x00;
   stream_toggle  = 0x00;
   use_out4       = FALSE;
   requested_outx = FALSE;

   /* wait for the requested block */
   while (OUT2CS & 0x02) ;
}

Byte retrieve_2bytes()
{
   Byte   i = 0;
   Byte err = 0;

   /* is there the need to get an additional packet from USB? */
   switch (pos_in_buf) {
      case 0x40:
         /* we need more data => another packet */
         err = request_if_available();

         /* will there be really a new packet? */
         if (err == 0) {
            /* wait for it */
            if (use_out4)
               while (OUT4CS & 0x02) ;
            else
               while (OUT2CS & 0x02) ;
            requested_outx = FALSE;

            /* we got a new packet :-) */
            pos_in_buf = 0x00;
            /* i is already initialized correctly */
            if (use_out4)
               while (i < 2)
                  retr[i++] = out4buf(pos_in_buf++);
            else
               while (i < 2)
                  retr[i++] = out2buf(pos_in_buf++);
         }

         break;

      default:
         /* we can live entirely out of the buffer */
         if (use_out4)
            while (i < 2)
               retr[i++] = out4buf(pos_in_buf++);
         else
            while (i < 2)
               retr[i++] = out2buf(pos_in_buf++);

         /* rearm buffer if this was the last portion */
         if (pos_in_buf == 0x40)
            request_if_available();

         break;
   }

   return(err);
}

Byte retrieve_4bytes()
{
   Byte   i = 0;
   Byte err = 0;

   /* is there the need to get an additional packet from USB? */
   switch (pos_in_buf) {
      case 0x3e:
         /* save the last two bytes */
         if (use_out4) {
            retr[0]    = out4buf(0x3e);
            retr[1]    = out4buf(0x3f);
         } else {
            retr[0]    = out2buf(0x3e);
            retr[1]    = out2buf(0x3f);
         }
         i          = 0x02; // remember this
         pos_in_buf = 0x40; // be nice and clean
         /* FALLTHROUGH */
      case 0x40:
         /* we need more data => another packet */
         err = request_if_available();

         /* will there be really a new packet? */
         if (err == 0) {
            /* wait for it */
            if (use_out4)
               while (OUT4CS & 0x02) ;
            else
               while (OUT2CS & 0x02) ;
            requested_outx = FALSE;

            /* we got a new packet :-) */
            pos_in_buf = 0x00;
            /* i is already initialized correctly */
            if (use_out4)
               while (i < 4)
                  retr[i++] = out4buf(pos_in_buf++);
            else
               while (i < 4)
                  retr[i++] = out2buf(pos_in_buf++);
         }

         break;

      default:
         /* we can live entirely out of the buffer */
         i = 0;
         if (use_out4)
            while (i < 4)
               retr[i++] = out4buf(pos_in_buf++);
         else
            while (i < 4)
               retr[i++] = out2buf(pos_in_buf++);

         /* rearm buffer if this was the last portion */
         if (pos_in_buf == 0x40)
            request_if_available();

         break;
   }

   return(err);
}
