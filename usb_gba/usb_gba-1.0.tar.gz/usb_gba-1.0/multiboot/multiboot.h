
/*
 *
 * $Id: multiboot.h,v 1.6 2002/05/05 16:54:22 arnim Exp $
 *
 * $Log: multiboot.h,v $
 * Revision 1.6  2002/05/05 16:54:22  arnim
 * use macros instead of pointer variables for USB buffers
 *
 * Revision 1.5  2002/05/05 15:26:24  arnim
 * move string_index in a separate file where it can be initialized in the CODE segment
 *
 * Revision 1.4  2002/04/20 22:44:29  arnim
 * add endpoint OUT4 and related variable
 *
 * Revision 1.3  2002/04/17 19:11:04  arnim
 * fix
 *
 * Revision 1.2  2002/04/17 19:00:43  arnim
 * add header
 *
 */

#include "dtypes.h"


/*
 * USB descriptor types
 */
#define USB_DT_DEVICE			0x01
#define USB_DT_CONFIG			0x02
#define USB_DT_STRING			0x03
#define USB_DT_INTERFACE		0x04
#define USB_DT_ENDPOINT			0x05

#define USB_DT_HID			0x21
#define USB_DT_REPORT			0x22
#define USB_DT_PHYSICAL			0x23
#define USB_DT_HUB			0x29

/* mapping for the setup packet */
struct setup_dat {
      Byte bmRequestType;
      Byte bRequest;
      Byte wValueL;
      Byte wValueH;
      Byte wIndexL;
      Byte wIndexH;
      Byte wLengthL;
      Byte wLengthH;
};

typedef struct setup_dat setup_dat;


/* the device descriptor */
static code Byte dev_desc[] = {
   0x12, // bLength             : Length of Descriptor
   0x01, // bDescriptorType     : Descriptor Type = Device
   0x00, // bcdUSB (L)          : USB Specification Version 1.00 (L)
   0x01, // bcdUSB (H)          : USB Specification Version 1.00 (H)
   0xff, // bDeviceClass        : Device Class (0xff is Vendor Specific)
   0xff, // bDeviceSubClass     : Device Sub-Class (0xff is Vendor Specific)
   0xff, // bDeviceProtocol     : Device Protocol (0xff is Vendor Specific)
   0x40, // bMaxPacketSize0     : Maximum Packet Size for EP0
   0xcd, // idVendor (L)        : Vendor ID (L)
   0x06, // idVendor (H)        : Vendor ID (H)
   0x02, // idProduct (L)       : Product ID (L)
   0xc0, // idProduct (H)       : Product ID (H)
   0x50, // bcdDevice (L)       : Device Release Number (BCD,L)
   0x01, // bcdDevice (H)       : Device Release Number (BCD,H)
   0x01, // iManufacturer       : Manufacturer Index String
   0x02, // iProduct            : Product Index String
   0x00, // iSerialNumber       : Serial Number Index String
   0x01  // bNumConfigurations  : Number of Configurations in this Device
};

/* the configuration descriptor */
static code Byte conf_desc[] = {
   0x09, // bLength             : Length of Descriptor
   0x02, // bDescriptorType     : Descriptor Type = Configuration
   0x27, // wTotalLength (L)    : Total Length (L) including Interface and Endpoint
   0x00, // wTotalLength (H)    : Total Length (H)
   0x01, // bNumInterfaces      : One Interface in this Configuration
   0x01, // bConfigurationValue : Configuration Value Used by Set_Configuration Request
         //                       to Select this Configuration
   0x00, // iConfiguration      : Index of String Describing this Configuration
   0x80, // bmAttributes        : Attributes
   0x32, // MaxPower            : Maximum Power

   //
   // The circular interface descriptor
   //
   // Interface 1, alternate setting 0
   0x09, // bLength             : Length of Descriptor
   0x04, // bDescriptorType     : Descriptor Type = Interface
   0x01, // bInterfaceNumber    : Zero-based index of this Interface
   0x00, // bAlternateSetting   : Alternate Setting
   0x03, // bNumEndpoints       : Number of Endpoints in this Interface
   0xff, // bInterfaceClass     : Interface Class (vendor)
   0xff, // bInterfaceSubClass  : Interface Sub-Class (vendor)
   0xff, // bInterfaceProtocol  : Interface Protocol (vendor)
   0x00, // iInterface          : Index to String Descriptor for this Interface

   // Endpoint Descriptor IN(2)
   0x07, // bLength             : Length of Descriptor
   0x05, // bDescriptorType     : Descriptor Type = Endpoint
   0x82, // bEndpointAddress    : Endpoint Address
   0x02, // bmAttributes        : Endpoint Attributes = Bulk
   0x40, // wMaxPacketSize (L)  : Maximum Packet Size (L)
   0x00, // wMaxPacketSize (H)  : Maximum Packet Size (H)
   0x00, // bInterval           : Polling intervall in Milliseconds
   // Endpoint Descriptor OUT(2)
   0x07, // bLength             : Length of Descriptor
   0x05, // bDescriptorType     : Descriptor Type = Endpoint
   0x02, // bEndpointAddress    : Endpoint Address
   0x02, // bmAttributes        : Endpoint Attributes = Bulk
   0x40, // wMaxPacketSize (L)  : Maximum Packet Size (L)
   0x00, // wMaxPacketSize (H)  : Maximum Packet Size (H)
   0x00, // bInterval           : Polling intervall in Milliseconds
   // Endpoint Descriptor OUT(4)
   0x07, // bLength             : Length of Descriptor
   0x05, // bDescriptorType     : Descriptor Type = Endpoint
   0x04, // bEndpointAddress    : Endpoint Address
   0x02, // bmAttributes        : Endpoint Attributes = Bulk
   0x40, // wMaxPacketSize (L)  : Maximum Packet Size (L)
   0x00, // wMaxPacketSize (H)  : Maximum Packet Size (H)
   0x00  // bInterval           : Polling intervall in Milliseconds
};


/* language ID string descriptor */
const code Byte string_langid[] = { 0x04, 0x03, 0x00, 0x00 };

/* manufacturer string descriptor */
const code Byte string_mfg[] = {
   0x22, 0x03,
   'A',0, 'C',0, 'M',0, 'E',0, ' ',0, 'u',0, 's',0, 'b',0,
   ' ',0, 'w',0, 'i',0, 'd',0, 'g',0, 'e',0, 't',0, 's',0
};

/* product string descriptor */
const code Byte string_prod[] = {
   0x62, 0x03,
   'M',0,'u',0,'l',0,'t',0,'i',0,'b',0,'o',0,'o',0,'t',0,' ',0,
   'I',0,'n',0,'t',0,'e',0,'r',0,'f',0,'a',0,'c',0,'e',0,' ',0,
   'f',0,'o',0,'r',0,' ',0,'N',0,'i',0,'n',0,'t',0,'e',0,'n',0,
   'd',0,'o',0,' ',0,'G',0,'a',0,'m',0,'e',0,'b',0,'o',0,'y',0,
   ' ',0,'A',0,'d',0,'v',0,'a',0,'n',0,'c',0,'e',0
};

#define NUM_STRING 3

extern code UInt16 string_index[NUM_STRING];


/*
 * global pointers
 */
//xdata Byte * data in0buf    = (xdata Byte *)&IN0BUF;
#define in0buf(n)  (&IN0BUF)[n]
#define out0buf(n) (&OUT0BUF)[n]
#define in2buf(n)  (&IN2BUF)[n]
#define out2buf(n) (&OUT2BUF)[n]
#define out4buf(n) (&OUT4BUF)[n]

static xdata setup_dat * data sdat = (xdata setup_dat *)&SETUPDAT;


/*
 * global shared variables
 */
data UInt32 ClientLength;
data UInt16 ClientPackets;
data Byte   retr[4];

//data UInt16 handover_value;

extern data Byte xfer_error;

/*
 * function prototypes
 */
UInt16 xfer(UInt16);
void   init_retriever(void);
Byte   retrieve_2bytes(void);
Byte   retrieve_4bytes(void);

void   init_xfer(void);
void   deinit_xfer(void);
