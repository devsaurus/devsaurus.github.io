
/*
 *
 * Prototypes of functions exported by nopper.asm.
 *
 * $Id: nopper.h,v 1.2 2002/04/21 21:59:37 arnim Exp $
 *
 */

/* for reference by assembler code */
void _nop31(void);
void _nop25(void);
void _nop21(void);
void _nop19(void);
void _nop8(void);
void _nop2(void);

/* for reference by C code */
void nop31(void);
void nop25(void);
void nop21(void);
void nop19(void);
void nop8(void);
void nop2(void);
