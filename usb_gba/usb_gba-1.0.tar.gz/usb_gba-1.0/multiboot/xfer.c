/*
 *
 * Copyright (C) 2002, Arnim Laeuger
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version. See also the file COPYING which
 *  came with this application.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * $Id: xfer.c,v 1.8 2002/05/05 19:57:23 arnim Exp $
 *
 * $Log: xfer.c,v $
 * Revision 1.8  2002/05/05 19:57:23  arnim
 * make functions with pure inline asm '_naked'
 *
 * Revision 1.7  2002/05/05 16:53:06  arnim
 * clarify usage of transfer
 *
 * Revision 1.6  2002/04/30 22:33:38  arnim
 * generate xfer_err upon timeout while waiting for startbit
 *
 * Revision 1.5  2002/04/21 22:00:01  arnim
 * use function protoypes from nopper.h
 *
 * Revision 1.4  2002/04/17 19:09:46  arnim
 * fix
 *
 * Revision 1.3  2002/04/17 19:04:14  arnim
 * adjust copyright
 *
 * Revision 1.2  2002/04/17 19:01:47  arnim
 * + cleanup
 * + add header
 *
 */


#include <8051.h>
#include "ezusb_reg.h"

#include "dtypes.h"
#include "nopper.h"


#define PB2 0x04
#define PB3 0x08
#define PB4 0x10
#define PB5 0x20

#define SO  (PB2)
#define SI  (PB3)
#define SD  (PB4)
#define SC  (PB5)

#define PC0 0x01
#define PC1 0x02
#define RXD (PC0)
#define TXD (PC1)


data Byte xfer_error;

/* transfer must be at 0x2f!
   xfer_byte and receive_byte rely on this - they use bit-addressing */
static data at 0x2f Byte transfer;


void wait_msec(Byte);


/*
 *  bit_time / CLK24/4
 *    8.68 us / 0.167 us = 51.97
 */
#define TIMER0_RELOAD (0xff - 26)


void deinit_xfer(void)
{
   /* set SI to '1', leave SO, SD and SC in input mode */
   OUTB  = SD | SC | SI;
   OEB   = SI;
}

void init_xfer(void)
{
   /* set SI to '1', leave SO, SD and SC in input mode */
   OUTB  = SD | SC | SI;
   OEB   = SI;
}



static void xfer_byte(void) _naked
{
   _asm
   /* startbit is on line */
   /* entry at cycle 10    */
   lcall _nop21
   /* bit 0               */
   mov  a, r0          //   ( 1)
   jnb  0x78, set0_lo  //   ( 5)
   orl  a, #SD         //   ( 7)
   sjmp set0           //   (10)
   set0_lo:            // ->( 5)
   nop                 //   ( 6)
   nop                 //   ( 7)
   nop                 //   ( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   set0:               // ->(10)
   movx @dptr, a       //   (13)

   //
   lcall _nop31
   /* bit 1               */
   mov  a, r0          //   ( 1)
   jnb  0x79, set1_lo  //   ( 5)
   orl  a, #SD         //   ( 7)
   sjmp set1           //   (10)
   set1_lo:            // ->( 5)
   nop                 //   ( 6)
   nop                 //   ( 7)
   nop                 //   ( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   set1:               // ->(10)
   movx @dptr, a       //   (13)

   //
   lcall _nop31
   /* bit 2               */
   mov  a, r0          //   ( 1)
   jnb  0x7a, set2_lo  //   ( 5)
   orl  a, #SD         //   ( 7)
   sjmp set2           //   (10)
   set2_lo:            // ->( 5)
   nop                 //   ( 6)
   nop                 //   ( 7)
   nop                 //   ( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   set2:               // ->(10)
   movx @dptr, a       //   (13)

   //
   lcall _nop31
   /* bit 3               */
   mov  a, r0          //   ( 1)
   jnb  0x7b, set3_lo  //   ( 5)
   orl  a, #SD         //   ( 7)
   sjmp set3           //   (10)
   set3_lo:            // ->( 5)
   nop                 //   ( 6)
   nop                 //   ( 7)
   nop                 //   ( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   set3:               // ->(10)
   movx @dptr, a       //   (13)

   //
   lcall _nop31
   /* bit 4               */
   mov  a, r0          //   ( 1)
   jnb  0x7c, set4_lo  //   ( 5)
   orl  a, #SD         //   ( 7)
   sjmp set4           //   (10)
   set4_lo:            // ->( 5)
   nop                 //   ( 6)
   nop                 //   ( 7)
   nop                 //   ( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   set4:               // ->(10)
   movx @dptr, a       //   (13)

   //
   lcall _nop31
   /* bit 5               */
   mov  a, r0          //   ( 1)
   jnb  0x7d, set5_lo  //   ( 5)
   orl  a, #SD         //   ( 7)
   sjmp set5           //   (10)
   set5_lo:            // ->( 5)
   nop                 //   ( 6)
   nop                 //   ( 7)
   nop                 //   ( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   set5:               // ->(10)
   movx @dptr, a       //   (13)

   //
   lcall _nop31
   /* bit 6               */
   mov  a, r0          //   ( 1)
   jnb  0x7e, set6_lo  //   ( 5)
   orl  a, #SD         //   ( 7)
   sjmp set6           //   (10)
   set6_lo:            // ->( 5)
   nop                 //   ( 6)
   nop                 //   ( 7)
   nop                 //   ( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   set6:               // ->(10)
   movx @dptr, a       //   (13)

   //
   lcall _nop31
   /* bit 7               */
   mov  a, r0          //   ( 1)
   jnb  0x7f, set7_lo  //   ( 5)
   orl  a, #SD         //   ( 7)
   sjmp set7           //   (10)
   set7_lo:            // ->( 5)
   nop                 //   ( 6)
   nop                 //   ( 7)
   nop                 //   ( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   set7:               // ->(10)
   movx @dptr, a       //   (13)

   ret
   _endasm;
}


static void receive_byte(void) _naked
{
   _asm

   /* bit 0               */
   movx a, @dptr       //   ( 3)
   anl  a, #SD         //   ( 5)
   jz   rec_set0_lo    //   ( 8)
   setb 0x78           //   (10)
   sjmp finish0        //   (13)
   rec_set0_lo:        // ->( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   nop                 //   (11)
   nop                 //   (12)
   nop                 //   (13)
   finish0:            // ->(13)
   //
   lcall _nop31

   /* bit 1               */
   movx a, @dptr       //   ( 3)
   anl  a, #SD         //   ( 5)
   jz   rec_set1_lo    //   ( 8)
   setb 0x79           //   (10)
   sjmp finish1        //   (13)
   rec_set1_lo:        // ->( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   nop                 //   (11)
   nop                 //   (12)
   nop                 //   (13)
   finish1:            // ->(13)
   //
   lcall _nop31

   /* bit 2               */
   movx a, @dptr       //   ( 3)
   anl  a, #SD         //   ( 5)
   jz   rec_set2_lo    //   ( 8)
   setb 0x7a           //   (10)
   sjmp finish2        //   (13)
   rec_set2_lo:        // ->( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   nop                 //   (11)
   nop                 //   (12)
   nop                 //   (13)
   finish2:            // ->(13)
   //
   lcall _nop31

   /* bit 3               */
   movx a, @dptr       //   ( 3)
   anl  a, #SD         //   ( 5)
   jz   rec_set3_lo    //   ( 8)
   setb 0x7b           //   (10)
   sjmp finish3        //   (13)
   rec_set3_lo:        // ->( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   nop                 //   (11)
   nop                 //   (12)
   nop                 //   (13)
   finish3:            // ->(13)
   //
   lcall _nop31

   /* bit 4               */
   movx a, @dptr       //   ( 3)
   anl  a, #SD         //   ( 5)
   jz   rec_set4_lo    //   ( 8)
   setb 0x7c           //   (10)
   sjmp finish4        //   (13)
   rec_set4_lo:        // ->( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   nop                 //   (11)
   nop                 //   (12)
   nop                 //   (13)
   finish4:            // ->(13)
   //
   lcall _nop31

   /* bit 5               */
   movx a, @dptr       //   ( 3)
   anl  a, #SD         //   ( 5)
   jz   rec_set5_lo    //   ( 8)
   setb 0x7d           //   (10)
   sjmp finish5        //   (13)
   rec_set5_lo:        // ->( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   nop                 //   (11)
   nop                 //   (12)
   nop                 //   (13)
   finish5:            // ->(13)
   //
   lcall _nop31

   /* bit 6               */
   movx a, @dptr       //   ( 3)
   anl  a, #SD         //   ( 5)
   jz   rec_set6_lo    //   ( 8)
   setb 0x7e           //   (10)
   sjmp finish6        //   (13)
   rec_set6_lo:        // ->( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   nop                 //   (11)
   nop                 //   (12)
   nop                 //   (13)
   finish6:            // ->(13)
   //
   lcall _nop31

   /* bit 7               */
   movx a, @dptr       //   ( 3)
   anl  a, #SD         //   ( 5)
   jz   rec_set7_lo    //   ( 8)
   setb 0x7f           //   (10)
   sjmp finish7        //   (13)
   rec_set7_lo:        // ->( 8)
   nop                 //   ( 9)
   nop                 //   (10)
   nop                 //   (11)
   nop                 //   (12)
   nop                 //   (13)
   finish7:            // ->(13)

   ret
   _endasm;
}


UInt16 xfer(UInt16 xfer_data) _naked
{
   /* prevent warning about unused variable */
   xfer_data = xfer_data;

   _asm
   // result    in r6,r7
   // xfer_data in r4, r5

   mov  r6, #0x00
   mov  r7, #0x00

   // initialize variables
   mov  r4, dpl    // xfer_data LSB
   mov  r5, dph    // xfer_data MSB
   mov  _xfer_error, #0x00

   // disable interrupts so that we are alone now
   clr  EA

   // wait for SD and SC to be '1'
   mov  r2, #250   // timeout value
   mov  dptr, #_PINSB
   wait_sd_sc:
   movx a, @dptr
   anl  a, # SD | SC
   cjne a, # SD | SC, not_got_sd_sc
   sjmp got_sd_sc
   not_got_sd_sc:
   djnz r2, wait_sd_sc

   // timed out
   mov  _xfer_error, #0x01
   setb EA
   mov  dpl, r6
   mov  dph, r7
   ret


   got_sd_sc:
   // grab SD and SC
   mov  dptr, #_OUTB
   mov  a, # SD | SC | SI
   movx @dptr, a

   // SD=1,SC=1,SI=1
   mov  dptr, #_OEB
   mov  a, # SD | SC | SI
   movx @dptr, a

   /* ********************************************************************* *
    * Send 16 bits to the GBA                                               *
    * ********************************************************************* */
   mov  dptr, #_OUTB
   movx a, @dptr
   anl  a, #~(SC | SD)
   mov  r0, a     // r0 keeps the inactive contents of OUTB
   movx @dptr, a  // SD=0,SC=0,SI=1
   // start bit is on SD

   nop                   // ( 1)
   nop                   // ( 2)
   nop                   // ( 3)
   nop                   // ( 4)
   mov  _transfer, r4    // ( 6)
   lcall _xfer_byte      // (10)


   /* RET consumed 4 cycles */
   mov  _transfer, r5    // ( 6)
   lcall _xfer_byte      // (10)

   /* last bit is on line
      RET consumed 4 cycles */
   lcall _nop31          // (43)
   nop                   // (44)
   nop                   // (45)
   nop                   // (46)

   /* send stopbit          */
   mov  a, r0            // (47)
   orl  a, #SD           // (49)
   movx @dptr, a         // (52)


   /* ********************************************************************* *
    * Receive 16 bits from the GBA                                          *
    * ********************************************************************* */

   /* stopbit is on line
      request reception from GBA */
   mov  dptr, #_OEB
   movx a, @dptr
   anl  a, #~SD          // SD is input now
   movx @dptr, a
   //
   mov  dptr, #_OUTB
   movx a, @dptr
   anl  a, #~SI          // SI = '0' -> request reception
   movx @dptr, a

   mov  dptr, #_PINSB
   mov  r2, #250          // timeout value
   wait_for_startbit:
   movx a, @dptr          // ( 3)
   anl  a, #SD            // ( 5)
   jz   got_startbit      // ( 8)
   djnz r2, wait_for_startbit

   /* timed out */
   mov  _xfer_error, #0x02
   mov  dptr, #_OUTB
   mov  a, #SI
   movx @dptr, a
   mov  dptr, #_OEB
   movx @dptr, a
   setb EA
   mov  dpl, r6
   mov  dph, r7
   ret

   got_startbit:          // ->( 8)
   lcall _nop31           //   (47)
   nop                    //   (48)
   nop                    //   (49)
   mov  _transfer, #0x00  //   (52)
   /* enter receiver with a 4-cycle shift */

   lcall _receive_byte    // ->(17)
   mov  r6, _transfer     //   (19)

   mov  _transfer, #0x00  //   (22)
   lcall _nop19           //   (49)
   /* enter receiver wih no additional shift */

   lcall _receive_byte    // ->(17)
   mov  r7, _transfer     //   (19)

   lcall _nop25           //   (52)
   /* read stopbit */
   movx a, @dptr
   anl  a, #SD
   jnz  got_stopbit
   /* stopbit is '0'! */
   mov  _xfer_error, #0x03

   got_stopbit:
   /* activate SI of GBA */
   mov  dptr, #_OUTB
   movx a, @dptr
   orl  a, #SI
   movx @dptr, a

   mov  r2, #150          // timeout value
   mov  dptr, #_PINSB
   wait_ack:
   movx a, @dptr
   anl  a, #SO
   jz   got_ack
   djnz r2, wait_ack
   /* timeout while waiting for ACK */
   mov  _xfer_error, #0x04
   got_ack:

   mov  r2, #150          // timeout value
   wait_nack:
   movx a, @dptr
   anl  a, #SO
   jnz  got_nack
   djnz r2, wait_nack
   /* timeout while waiting for NACK */
   mov  _xfer_error, #0x05
   got_nack:

   mov  dptr, #_OUTB
   movx a, @dptr
   orl  a, #SC
   movx @dptr, a


   /* ********************************************************************* *
    * End of transfer                                                       *
    * ********************************************************************* */
   mov  dptr, #_OEB
   mov  a, #SI
   movx @dptr, a
   mov  dptr, #_OUTB
   mov  a, # SD | SC | SI
   movx @dptr, a

   setb EA

   mov  dpl, r6
   mov  dph, r7

   ret
   _endasm;
}
