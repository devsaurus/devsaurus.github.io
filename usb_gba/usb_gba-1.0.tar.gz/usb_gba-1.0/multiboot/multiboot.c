/*
 *
 * Copyright (C) 2002, Arnim Laeuger
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version. See also the file COPYING which
 *  came with this application.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * Thanks to:
 * ==========
 *   + http://program.at/Andrew
 *   + http://www.godsmaze.org/gba 
 *
 *
 * $Id: multiboot.c,v 1.13 2002/07/16 21:20:07 arnim Exp $
 *
 * $Log: multiboot.c,v $
 * Revision 1.13  2002/07/16 21:20:07  arnim
 * credits
 *
 * Revision 1.12  2002/05/13 20:47:44  arnim
 * adjust error codes
 *
 * Revision 1.11  2002/05/05 19:58:30  arnim
 * + correct handling of NOOVERLAY pragma:
 *   SAVE options before, RESTORE them afterwards
 * + no need for 'critical' functions
 *
 * Revision 1.10  2002/05/05 17:14:29  arnim
 * + use macros instead of pointer variables for USB buffers
 * + don't allocate data registers explicitely
 *
 * Revision 1.9  2002/05/05 15:28:52  arnim
 * doku, formatting
 *
 * Revision 1.8  2002/05/01 20:04:15  arnim
 * more comments
 *
 * Revision 1.7  2002/04/30 22:33:03  arnim
 * + remove send_over_in2()
 * + activate timeout in wait_for_0x0075()
 * + check xfer_error after every call to xfer()
 *   the resulting error is or'ed with a unique indentifier
 *
 * Revision 1.6  2002/04/21 21:59:14  arnim
 * use function wait_for_0x0075() when waiting for ACK from GBA
 * has currently no timout functionality -> to be tested
 *
 * Revision 1.5  2002/04/20 22:45:09  arnim
 * initialize additional endpoint OUT4
 *
 * Revision 1.4  2002/04/17 19:10:10  arnim
 * fix
 *
 * Revision 1.3  2002/04/17 19:04:14  arnim
 * adjust copyright
 *
 * Revision 1.2  2002/04/17 19:02:48  arnim
 * + cleanup
 * + remove header
 *
 */


#include <8051.h>
#include "ezusb_reg.h"

#include "multiboot.h"
#include "nopper.h"


/*****************************************************************************
 * get_descriptor()
 *
 * Sends the requested descriptor back to the host.
 * Currently supported descriptor types are:
 *   + device
 *   + configuration
 *   + string
 *****************************************************************************/
#pragma SAVE
#pragma NOOVERLAY
static void get_descriptor(void) using 1
{
   switch (sdat->wValueH) {
         /* type: device */
      case USB_DT_DEVICE:
         EP0CS   = 0x02;   /* clear HSNACK */
         SUDPTRH = (Byte)((unsigned int)dev_desc >> 8);
         SUDPTRL = (unsigned int)dev_desc & 0xff;
         break;

         /* type: configuration */
      case USB_DT_CONFIG:
         EP0CS   = 0x02;   /* clear HSNACK */
         SUDPTRH = (Byte)((unsigned int)conf_desc >> 8);
         SUDPTRL = (unsigned int)conf_desc & 0xff;
         break;

         /* type: string */
      case USB_DT_STRING:
         if (sdat->wValueL < NUM_STRING) {
            EP0CS     = 0x02;   /* clear HSNACK */
            SUDPTRH = (Byte)(string_index[sdat->wValueL] >> 8);
            SUDPTRL = string_index[sdat->wValueL] & 0xff;
         } else {
            EP0CS     = 0x01;   /* stall */
         }
         break;

      default:
         EP0CS     = 0x01;   /* stall */
         break;
   }
}
#pragma RESTORE


/*****************************************************************************
 * usb_isr()
 *
 * USB interrupt service routine
 * Performs five major tasks:
 *   + parse the SETUP packets upon SUDAV interrupt and answer them
 *   + ack IN0 interrupts
 *   + ack IN1 interrupts
 *   + ack IN2 interrupts
 *   + ack OUT0 interrupts
 *****************************************************************************/
static void usb_isr(void) interrupt 8 using 1
{
   /* clear INT2 interrupt */
   EXIF &= 0xef;

   /* was this the SUDAV interrupt? */
   if (USBIRQ & 0x01) {

      /* clear SUDAV interrupt */
      USBIRQ = 0x01;

      switch (sdat->bRequest) {

         /* bRequest == 0x00 */
         case 0x00:
            switch (sdat->bmRequestType) {
               /* GetStatus(Device) TODO */
               case 0x80:
                  /* GetStatus(Interface) */
               case 0x81:
                  /* GetStatus(Endpoint) TODO*/
               case 0x82:
                  in0buf(0) = 0x00;
                  in0buf(1) = 0x00;
                  IN0BC     = 0x02;
                  EP0CS     = 0x02;   /* clear HSNACK */
                  break;

               default:
                  EP0CS     = 0x01;   /* stall */
                  break;
            }
            break;

            /* bRequest == 0x01 */
         case 0x01:
            switch (sdat->bmRequestType) {
                  /* ClearFeature(Device) TODO */
               case 0x00:
                  EP0CS     = 0x02;   /* clear HSNACK */
                  break;
                  /* ClearFeature(Interface) TODO */
               case 0x01:
                  EP0CS     = 0x02;   /* clear HSNACK */
                  break;
                  /* ClearFeature(Endpoint) */
               case 0x02:
                  switch (sdat->wValueL) {
                     case 0x00:  /* OUT0 */
                     case 0x80:  /* IN0  */
                        EP0CS  = 0x02;   /* clear HSNACK */
                        break;
                     case 0x82:  /* IN2  */
                        IN2CS &= 0xfe;  /* unstall endpoint */
                        EP0CS  = 0x02;  /* clear HSNACK */
                        break;
                     case 0x02:  /* OUT2 */
                        OUT2CS &= 0xfe;  /* unstall endpoint */
                        EP0CS   = 0x02;  /* clear HSNACK */
                        break;
                     case 0x04:  /* OUT4 */
                        OUT4CS &= 0xfe;  /* unstall endpoint */
                        EP0CS   = 0x02;  /* clear HSNACK */
                        break;
                     default:
                        EP0CS = 0x01;   /* stall */
                        break;
                  }
                  break;

               default:
                  EP0CS     = 0x01;   /* stall */
                  break;
            }
            break;

            /* SetFeature */
         case 0x03:
            switch (sdat->bmRequestType) {
                  /* SetFeature(Device) TODO */
               case 0x00:
                  EP0CS     = 0x02;   /* clear HSNACK */
                  break;
                  /* SetFeature(Interface) TODO */
               case 0x01:
                  EP0CS     = 0x02;   /* clear HSNACK */
                  break;
                  /* SetFeature(Endpoint) */
               case 0x02:
                  switch (sdat->wIndexL) {
                     case 0x00:  /* OUT0 */
                        EP0CS  |= 0x01;  /* stall endpoint */
                        TOGCTL  = 0x00;
                        TOGCTL  = 0x20;
                        OUT0BC  = 0x00;
                        EP0CS  |= 0x02;  /* clear HSNACK */
                        break;
                     case 0x80:  /* IN0  */
                        EP0CS  |= 0x01;  /* stall endpoint */
                        TOGCTL  = 0x10;
                        TOGCTL  = 0x30;
                        EP0CS  |= 0x02;  /* clear HSNACK */
                        break;
                     case 0x82:  /* IN2  */
                        IN2CS   = 0x01;  /* stall endpoint */
                        TOGCTL  = 0x12;
                        TOGCTL  = 0x32;
                        EP0CS   = 0x02;  /* clear HSNACK */
                        break;
                     case 0x02:  /* OUT2 */
                        OUT2CS  = 0x01;  /* stall endpoint */
                        TOGCTL  = 0x02;
                        TOGCTL  = 0x22;
                        OUT2BC  = 0x00;
                        EP0CS   = 0x02;  /* clear HSNACK */
                        break;
                     case 0x04:  /* OUT4 */
                        OUT4CS  = 0x01;  /* stall endpoint */
                        TOGCTL  = 0x04;
                        TOGCTL  = 0x24;
                        OUT4BC  = 0x00;
                        EP0CS   = 0x02;  /* clear HSNACK */
                        break;
                     default:
                        EP0CS  = 0x01;   /* stall */
                        break;
                  }
                  break;

               default:
                  EP0CS     = 0x01;   /* stall */
                  break;
            }
            break;

            /* GetDescriptor */
         case 0x06:
            get_descriptor(/*sdat*/);
            break;

            /* GetConfiguration */
         case 0x08:
            if (sdat->bmRequestType == 0x80) {
               in0buf(0) = 0x01;
               IN0BC     = 0x01;
               EP0CS     = 0x02;   /* clear HSNACK */
            } else {
               EP0CS     = 0x01;   /* stall */
            }
            break;

            /* SetConfiguration */
         case 0x09:
            switch (sdat->bmRequestType) {
                  /* SetConfiguration */
               case 0x00:
                  EP0CS     = 0x02;   /* clear HSNACK */
                  break;

               default:
                  EP0CS     = 0x01;   /* stall */
                  break;
            }
            break;

            /* bRequest == 0x0a */
         case 0x0a:
            switch (sdat->bmRequestType) {
               /* GetInterface */
               case 0x81:
                  in0buf(0) = 0x00;
                  IN0BC     = 0x01;
                  EP0CS     = 0x02;   /* clear HSNACK */
                  break;

               default:
                  EP0CS     = 0x01;   /* stall */
                  break;
            }
            break;

            /* bRequest == 0x0b */
         case 0x0b:
            switch (sdat->bmRequestType) {
                  /* SetInterface */
               case 0x01:
                  if (sdat->wValueL == 0) { /* only AS 0 supported */
                     if (sdat->wIndexL == 0) {
                        IN2CS  &= 0xfd;     /* remove busy */
                        TOGCTL = 0x12;
                        TOGCTL = 0x32;      /* reset toggle of IN2*/

                        TOGCTL = 0x02;
                        TOGCTL = 0x22;      /* reset toggle of OUT2 */
                        OUT2BC = 0x00;

                        TOGCTL = 0x04;
                        TOGCTL = 0x24;      /* reset toggle of OUT4 */
                        OUT4BC = 0x00;

                        EP0CS     = 0x02;   /* clear HSNACK */
                     } else
                        EP0CS  = 0x01;   /* stall */
                  } else
                     EP0CS  = 0x01;   /* stall */
                  break;

                  /* Set_Protocol TODO */
               case 0x21:
                  EP0CS     = 0x02;   /* clear HSNACK */
                  break;

               default:
                  EP0CS     = 0x01;   /* stall */
                  break;
            }
            break;

         default:
            EP0CS     = 0x01;   /* stall */
            break;
      }


   }

   /* was this an IN0 interrupt? */
   if (IN07IRQ & 0x01) {
      /* clear IN0 interrupt */
      IN07IRQ = 0x01;
   }

   /* was this a OUT0 interrupt? */
   if (OUT07IRQ & 0x01) {
      /* clear OUT0 interrupt */
      OUT07IRQ = 0x01;

      /* arm endpoint again */
      OUT0BC = 0x00;
   }

   /* was this the URES interrupt? */
   if (USBIRQ & 0x10) {
      /* clear request */
      USBIRQ = 0x10;
   }
}



/*****************************************************************************
 * setup_usb_int()
 *
 * Setup the USB interrupts.
 *****************************************************************************/
static void setup_usb_int()
{
   /* disable global interrupt */
   EA       = 0;

   /* clear autovector enable */
   USBBAV   = 0x00;
   /* clear SUDAV interrupt and all other interrupts */
   USBIRQ   = 0xff;
   /* enable SUDAV and URES interrupts */
   USBIEN   = 0x11;

   /* clear IN0, IN1 and IN2 interrupts */
   IN07IRQ  = 0x07;
   /* enable IN0 interrupt */
   IN07IEN  = 0x01;
   /* clear OUT0 interrupt */
   OUT07IRQ = 0x01;
   /* enable OUT0 interrupt */
   OUT07IEN = 0x01;

   /* unstall endpoints */
   IN2CS    = 0x00;
   OUT2CS   = 0x00;
   OUT4CS   = 0x00;

   /* validate endpoints */
   IN07VAL  = 0x05;
   OUT07VAL = 0x15;

   /* enable external 2 interrupt */
   EUSB     = 1;

   /* enable global interrupt */
   EA       = 1;
}


/*****************************************************************************
 * wait_msec(n)
 *
 * Wait at least n milliseconds. Timed by SOF token on USB.
 *****************************************************************************/
void wait_msec(Byte n)
{
   /* prevent warning about unused variable n */
   n = n;

   _asm
   mov  r1, dpl
   mov  r2, #0x02
   /* clear a previous interrupt request */
   mov  dptr, #_USBIRQ
   mov  a, r2
   movx @dptr, a

   /* sync to SOFIR */
   $0001:
   movx a, @dptr
   anl  a, r2
   jz   $0001
   mov  a, r2
   movx @dptr, a

   /* wait for n * 1 ms */
   $0002:
   movx a, @dptr
   anl  a, r2
   jz   $0002
   mov  a, r2
   movx @dptr, a

   djnz r1, $0002

   _endasm ;
}


/*****************************************************************************
 * skip_rest()
 *
 * Skip rest of data stream. Calls retrieve_4bytes until all expected data
 * has been retrieved.
 *****************************************************************************/
static void skip_rest(void)
{
   /* consume the rest */
   while (retrieve_4bytes() == 0) ;
}


/*****************************************************************************
 * wait_for_0x0075(RData, send_data16)
 *
 * Transmits send_data16 to GBA until 0x0075 is received.
 * Function is declared reentrant to force SDCC to allocate local variables
 * on the stack.
 *****************************************************************************/
static void wait_for_0x0075(UInt16 RData, UInt16 send_data16) reentrant
{
   Byte   timeout = 200;

   while (RData != 0x0075) {
      RData = xfer((UInt16)send_data16);          // While no ack from the GBA
      if (timeout-- == 0)
         break;
      _asm
      lcall _nop31
      lcall _nop31
      lcall _nop31
      lcall _nop31
      lcall _nop31
      _endasm;
   } 
}


/*****************************************************************************
 * transmit_data()
 *
 * Handles the complete data transmission in multiboot mode.
 * Returns error code which identifies the error location:
 *   0x00 : all ok
 *   LSN  : error from xfer()
 *   MSN  : location in transmit_data() where xfer_error occured
 *****************************************************************************/
static Byte transmit_data()
{
   data   Byte   i;
   UInt16 RData;

   data Byte   still_sending;
   data Byte var_1;
   data Byte var_8;
   UInt32 var_C, encrypt_seed, client_pos;
   UInt32 send_data16;
   UInt16 send_data16_high;
   UInt32 data32, CRCTemp, var_30;


   RData = 0;
   i     = 10;
   while (RData != 0x7202) {
      RData = xfer(0x6202);
      if (xfer_error) {
         return(xfer_error);
      }
      if (i-- == 0)
         break;
   }

   if (i == 0)
      return(15);

   xfer(0x6100);
   if (xfer_error)
      return(0x10 | xfer_error);

   /* send 0x60 words with no encryption */
   for (i = 0; i <= 0x5f; i++) {
      retrieve_2bytes();
      xfer((UInt16)(retr[1] << 8) | (UInt16)retr[0]);
      if (xfer_error)
         return(0x20 | xfer_error);
   }

   xfer(0x6202);
   if (xfer_error)
      return(0x30 | xfer_error);

   xfer(0x63c1);
   if (xfer_error)
      return(0x40 | xfer_error);

   RData = xfer(0x63c1);                                      // get encryption value
   if (xfer_error)
      return(0x50 | xfer_error);

   encrypt_seed = ((UInt32)(RData & 0x0FF) << 8) | 0x0FFFF00C1;    // looks like an encryption value
   var_1        = (UInt16)((RData & 0x0FF) + 0x20F);

   RData        = xfer((UInt16)(var_1 & 0x00ff) | 0x6400);         // encryption confirmation?
   if (xfer_error)
      return(0x60 | xfer_error);

//   wait_msec(1);

   RData = xfer((UInt16)((ClientLength - 0xc0) >> 2) - 0x34);
   if (xfer_error)
      return(0x70 | xfer_error);

   var_8         = RData;
   var_C         = 0x0FFF8;
   client_pos    = 0x0C0;
   still_sending = 0x02;

   send_data16_high = 0;
   do {
      send_data16 = (UInt32)send_data16_high; // Prepare to xfer bits31;16 (only useful every second time)
      if (!(client_pos & 0x02)) {             // every 'odd' time through (iteration 1,3,5,...)
         retrieve_4bytes();
         data32 = ((UInt32)retr[3] << 0x18) | ((UInt32)retr[2] << 0x10) |
                  ((UInt32)retr[1] << 0x08) |  (UInt32)retr[0];

         CRCTemp = data32;

         for (i = 0; i <= 31; i++) {      // CRC Calculation (???)
            var_30   = var_C ^ CRCTemp;   //
            var_C    = var_C >> 1;        //
            CRCTemp  = CRCTemp >> 1;      //
            if (var_30 & 0x01)            //
               var_C = var_C ^ 0x0A517;   //
         }                                //

         encrypt_seed = (encrypt_seed * 0x6F646573) + 1; // Calculate new encryption value

         send_data16 = (encrypt_seed ^ data32) ^                       // encrypt data
                      ( ((~(client_pos + 0x2000000)) + 1) ^ 0x6465646F); //

         send_data16_high = (UInt16)(send_data16 >> 16); // The upper 16 bits to be sent 
	                                                    // in second transfer
	                                          
         send_data16 = send_data16 & 0x0FFFF;    
      }

      while (1) {
         if (client_pos != 0xc0) {           // if already sent (client_pos!=0xc0)
            if (RData != (UInt16)((client_pos - 2) & 0xffff))  { //  Check the Return value
               return(101);                                      // (address of last data sent)
            }                                                    // should be client_pos - 2
         }
         RData = xfer((UInt16)(send_data16 & 0xffff));           // Send 16 bits of encrypted data
         if (xfer_error)
            break;

         if (still_sending) {
            client_pos += 2;                                     // Next 16 bits of data
            if ((still_sending == 2) && (client_pos != ClientLength))  // still doing data transfer
               break;
            send_data16 = 0x65;                                  // The end of data signal to be sent twice
            still_sending--;                                     // Controls Data/Enddata/Enddata
         } else
            break;

      }

   } while (still_sending && !xfer_error);
   if (xfer_error)
      return(0x80 | xfer_error);


   /* ********************************************************************* *
    * CRC checking                                                          *
    * ********************************************************************* */

//   while (RData != 0x0075)
//      RData = xfer((UInt16)send_data16);          // While no ack from the GBA
   wait_for_0x0075(RData, (UInt16)send_data16);

   RData = xfer(0x0066);                          // Send transfer end signal
   if (xfer_error)
      return(0x90 | xfer_error);

   data32 = (((UInt32)((RData & 0xFF00) | (UInt16)var_8) << 8) | 0xFFFF0000) | (UInt32)var_1; //  CRC value
   for (i = 0; i <= 31; i++) {                                        //
      var_30    = var_C ^ data32;                                     //
      var_C     = var_C >> 1;                                         //
      data32    = data32 >> 1;                                        //
      if (var_30 & 0x01)                                              //
         var_C  = var_C ^ 0x0A517;                                    //
   }

   RData = xfer((UInt16)(var_C & 0xffff));                            // Send CRC value
   if (xfer_error)
      return(0xa0 | xfer_error);

   /* pre-load in2buf with both CRC results */
   in2buf(2) = (Byte)(var_C & 0xff);
   in2buf(3) = (Byte)((var_C >> 8) & 0xff);
   in2buf(4) = (Byte)(RData & 0xff);
   in2buf(5) = (Byte)((RData >> 8) & 0xff);

   /* final comparison of CRC value */
   if ((UInt16)(var_C & 0xffff) == RData)
      return(0);
   else
      return(10);
}


static void multiboot()
{
   data Byte result;
   Byte i;
   bit err;

   /* Pair OUT2 and OUT3
      Pair OUT4 and OUT5
      Pair IN2 and IN3 */
   USBPAIR = 0x19;

   OUT2BC = 0x00;

   while (TRUE) {

      init_xfer();

      while (OUT2CS & 0x02) ;
      /* data available at OUT2BUF */

      /* check for 'WS' */
      if ((out2buf(0) == 'W') && (out2buf(1) == 'S')) {
         /* answer with 'RR' */
         out2buf(0) = 'R';
         out2buf(1) = 'R';
         /* ClientLength  : total number of bytes to be transferred */
         ClientLength = ((UInt32)out2buf(2) << 24) |
                        ((UInt32)out2buf(3) << 16) |
                        ((UInt32)out2buf(4) <<  8) |
                        ((UInt32)out2buf(5)      );

         /* ClientPackets : number of packets == number of bytes / 64 */
         ClientPackets = ((UInt16)out2buf(6) <<  8) |
                         ((UInt16)out2buf(7)      );

         err = FALSE;
      } else {
         /* send error code */
         out2buf(0) = 'E';
         out2buf(1) = '0';

         err = TRUE;
      }

//      send_over_in2(out2buf, 6);
      while (IN2CS & 0x02) ;
      i = 6;
      while (i-- > 0)
         in2buf(i) =  out2buf(i);
      /* send answer over IN2BUF */
      IN2BC  = 6;  /* arm IN2 */


      OUT2BC = 0x00;  /* rearm OUT2 */


      if (!err) {

         init_retriever();

         /* get GBA attention, send header and data */
         result = transmit_data();
         /* consume the remaining data */
         skip_rest();

         if (result == 0x00) {

            in2buf(0) = 'F';
            in2buf(1) = 'D';
            // send data over IN2BUF
            IN2BC  = 6;  // arm IN2
         } else {

            in2buf(0) = 'E';
            in2buf(1) = result;
            IN2BC     = 6;
         }

         deinit_xfer();
      }

   }

}


/*****************************************************************************
 * _sdcc_external_startup()
 *
 * Earliest possibility to disconnect for re-enumeration.
 * This is not necessary when the firmware resides in the onboard I2C EEPROM
 * where the master control is handed back to the USB core to let it talk to
 * the host. Afterwards we perform a clean re-enumeration.
 *****************************************************************************/
Byte _sdcc_external_startup()
{
   /* disconnect immediately */
   USBCS &= ~0x04;    // tristate the Disconnect pin
   USBCS |= 0x08;     // disconnect USB core

   return(0);
}


/*****************************************************************************
 * main()
 *
 * Main function.
 * Call initializers, trigger re-enumeration and stay busy in endless loop.
 * All functionality is handled in the interrupt service routines.
 *****************************************************************************/
void main()
{
   int loop;

   loop = 16384;
   while (loop-- > 0) ;

   setup_usb_int();

   USBCS |= 0x02;     // activate RENUM
   USBCS &= ~0x08;    // deactivate DISCON
   USBCS |= 0x04;     // release tristate on Disconnect pin

   multiboot();

   while (TRUE) ;
}
