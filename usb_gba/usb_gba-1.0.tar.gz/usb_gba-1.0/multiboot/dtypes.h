
/*
 *
 * $Id: dtypes.h,v 1.3 2002/04/17 19:10:35 arnim Exp $
 *
 * $Log: dtypes.h,v $
 * Revision 1.3  2002/04/17 19:10:35  arnim
 * fix
 *
 * Revision 1.2  2002/04/17 19:00:50  arnim
 * add header
 *
 */


#ifndef __DTYPES_H__
#define __DTYPES_H__


#if !defined (TRUE)
#define TRUE (1==1)
#endif
#if !defined (FALSE)
#define FALSE (!TRUE)
#endif


/* our main data type */
typedef unsigned char Byte;

typedef          int  Int16;
typedef unsigned int  UInt16;
typedef          long Int32;
typedef unsigned long UInt32;


#endif /* __DTYPES_H__ */
