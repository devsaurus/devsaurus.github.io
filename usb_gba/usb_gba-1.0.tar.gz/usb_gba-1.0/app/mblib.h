
/*
 * $Id: mblib.h,v 1.3 2002/05/24 22:25:39 arnim Exp $
 */

extern void (*write_stream_callback) (u_int32_t, u_int32_t);

int write_stream_n(int, usb_dev_handle *, u_int8_t *, u_int32_t, u_int32_t *,
                   int, int);

int write_double_streamed(usb_dev_handle *, u_int8_t *, u_int32_t, int);

usb_dev_handle *open_gba(u_int16_t, u_int16_t, int);

int init_gba_transfer(usb_dev_handle *, u_int32_t, u_int16_t, int);

int prepare_file(char *, u_int8_t **, u_int32_t *, u_int16_t *, int);
