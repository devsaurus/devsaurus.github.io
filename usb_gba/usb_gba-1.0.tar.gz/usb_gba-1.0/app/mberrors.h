
/*
 * $Id: mberrors.h,v 1.1 2002/05/13 20:46:21 arnim Exp $
 */

/* mapping of error codes from the high-level multiboot protocol */
char *multiboot_errors[0x10] = {
   "Initial 0x7202 sync failed",                        // 0x0
   "TX of 0x6100 failed",                               // 0x1
   "TX of 0x60 words with no encryption failed",        // 0x2
   "TX of 0x6202 failed",                               // 0x3
   "TX of first 0x63c1 failed",                         // 0x4
   "TX of second 0x63c1 failed",                        // 0x5
   "TX of encryption confirmation failed",              // 0x6
   "TX of adjusted ClientLength failed",                // 0x7
   "TX of main data failed",                            // 0x8
   "TX of 0x0066 (transmission end signal) failed",     // 0x9
   "TX of CRC value failed",                            // 0xa
   "",                                                  // 0xb
   "",                                                  // 0xc
   "",                                                  // 0xd
   "",                                                  // 0xe
   ""                                                   // 0xf
};

/* mapping of error codes from the low-level xfer layer */
char *xfer_errors[0x10] = {
   "I am no error",                                     // 0x0
   "Timeout while waiting for inactive SD and SC",      // 0x1
   "Timeout while waiting for startbit from GBA",       // 0x2
   "Wrong stopbit from GBA (is '0')",                   // 0x3
   "Timeout while waiting for ACK from GBA",            // 0x4
   "Timeout while waiting for NACK from GBA"            // 0x5
   "",                                                  // 0x6
   "",                                                  // 0x7
   "",                                                  // 0x8
   "",                                                  // 0x9
   "CRC value mismatch",                                // 0xa
   "",                                                  // 0xb
   "",                                                  // 0xc
   "",                                                  // 0xd
   "",                                                  // 0xe
   ""                                                   // 0xf
};
