/*
 *
 * Copyright (C) 2002, Arnim Laeuger
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version. See also the file COPYING which
 *  came with this application.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * $Id: mblib.c,v 1.4 2002/05/24 22:25:30 arnim Exp $
 *
 * $Log: mblib.c,v $
 * Revision 1.4  2002/05/24 22:25:30  arnim
 * add debug parameter
 *
 * Revision 1.3  2002/05/23 21:39:25  arnim
 * prepare usage of a callback function that handles different user interface methods
 *
 * Revision 1.2  2002/05/13 19:05:29  arnim
 * move all functions related to the EZ-USB device into an own library
 *
 * Revision 1.1  2002/05/12 21:56:04  arnim
 * move all functions related to the multiboot protocol into an own library
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>

#include <usb.h>

#include "pagesize.h"
#include "mbheader.h"
#include "ezusblib.h"


void (*write_stream_callback) (u_int32_t, u_int32_t) = NULL;


int write_stream_n(int stream, usb_dev_handle *gba, u_int8_t *buffer, u_int32_t len,
                   u_int32_t *written, int result, int debug)
{
   int send_now;

   if (stream == 0) {
      /* pre-load OUT4 */
      if (len - *written > PAGESIZE - result) {
         send_now = len - *written - (PAGESIZE - result);
         send_now = send_now > OVERLAP ? OVERLAP : send_now;
         /* update written count now that we don't need previous result anymore */
         *written += result;
         result = usb_bulk_write(gba, 0x04,
                                 &(buffer[*written + (PAGESIZE - result)]), send_now, 1000);
      } else {
         /* update written count now that we don't need previous result anymore */
         *written += result;
         result = 1;
      }

      if (result > 0) {
         /* transfer the remaining bytes for OUT2 */
         send_now = len - *written;
         send_now = send_now > PAGESIZE - (*written & OVERLAP) ? PAGESIZE - (*written & OVERLAP) : send_now;
         if (send_now > 0) {
            /* continue if there is still something to send */
            result   = usb_bulk_write(gba, 0x02,
                                      &(buffer[*written]), send_now, 1000);

            if (result > 0) {
               *written += result;
               if (write_stream_callback)
                  write_stream_callback(len, *written);
            } else {
               if (debug)
                  printf("Error while transferring the remaining bytes over OUT2, written: %d, send_now: %d\n",
                         *written, send_now);
            }
         }
      } else {
         if (debug)
            printf("Error while pre-loading OUT4, written: %d\n", *written);
      }

   } else if (stream == 1) {

      /* pre-load OUT2 */
      if (len - *written > PAGESIZE) {
         send_now = len - *written - PAGESIZE;
         send_now = send_now > OVERLAP ? OVERLAP : send_now;
         result = usb_bulk_write(gba, 0x02,
                                 &(buffer[*written + PAGESIZE]), send_now, 1000);
      } else
         result = 1;

      if (result > 0) {
         /* transfer the remaining bytes for OUT4 */
         *written += OVERLAP;  // was pre-loaded
         send_now = len - *written;
         send_now = send_now > PAGESIZE - OVERLAP ? PAGESIZE - OVERLAP : send_now;
         if (send_now > 0) {
            /* continue if there is still something to send */
            result   = usb_bulk_write(gba, 0x04,
                                      &(buffer[*written]), send_now, 1000);
            if (result > 0)
               *written += result;
            else {
               if (debug)
                  printf("Error while transferring the remaining bytes over OUT4, written: %d, send_now: %d\n",
                         *written, send_now);
            }
            if (write_stream_callback)
               write_stream_callback(len, *written);

         }
         /* insert the pre-loaded (and now written count) for OUT2 */
         result = OVERLAP;
      } else {
         if (debug)
            printf("Error while pre-loading OUT2, written: %d\n", *written);
      }
   }

   return(result);
}


int write_double_streamed(usb_dev_handle *gba, u_int8_t *buffer, u_int32_t len, int debug)
{
   u_int32_t written;
   int       result;

   written = 0;
   result  = 0;
   do {
      result = write_stream_n(0, gba, buffer, len, &written, result, debug);
      if (result > 0)
         result = write_stream_n(1, gba, buffer, len, &written, result, debug);
   } while ((written < len) && (result >= 0));

   return(result > 0 ? written : result);
}


usb_dev_handle *open_gba(u_int16_t idVendor, u_int16_t idProduct, int debug)
{
   struct usb_bus    *bus = NULL;
   struct usb_device *dev = NULL;
   struct usb_device *gba_dev = NULL;
   usb_dev_handle    *gba = NULL;

   usb_init();
   usb_find_busses();
   usb_find_devices();

   for (bus = usb_busses; bus; bus = bus->next) {
      for (dev = bus->devices; dev; dev = dev->next)
         if ((dev->descriptor.idVendor == idVendor) &&
             (dev->descriptor.idProduct == idProduct)) {
            if (debug)
               printf("Found a GBA USB adapter at bus %s, device %s\n", bus->dirname,
                      dev->filename);
            gba_dev = dev;
         }
   }

   if (gba_dev)
      gba = usb_open(gba_dev);

   return(gba);
}


int init_gba_transfer(usb_dev_handle *gba, u_int32_t len, u_int16_t packets, int debug)
{
   int result, i;
   u_int8_t command[16];

   result = usb_claim_interface(gba, 1);
   if (debug)
      printf("Result of usb_claim_interface(): %d\n", result);

   if (result == 0) {

      command[0] = 'W';
      command[1] = 'S';
      command[2] = (u_int8_t)((len >> 24) & 0xff);
      command[3] = (u_int8_t)((len >> 16) & 0xff);
      command[4] = (u_int8_t)((len >>  8) & 0xff);
      command[5] = (u_int8_t)( len        & 0xff);
      command[6] = (u_int8_t)((packets >>  8) & 0xff);
      command[7] = (u_int8_t)( packets        & 0xff);
      result = usb_bulk_write(gba, 0x02, command, 0x08, 1000);
      if (debug)
         printf("Result of usb_bulk_write(): %d\n", result);

      result = usb_bulk_read(gba, 0x82, command, 0x06, 1000);
      if (debug)
         printf("Result of usb_bulk_read(): %d\n", result);
      if (result >= 0) {
         if (debug)
            printf("  Received: %c%c  ", command[0], command[1]);

         if ((command[0] == 'R') && (command[1] == 'R')) {
            if (debug) {
               for (i = 0; i < 4; i++)
                  printf("0x%02x ", command[i+2]);
               printf("\n");
            }

            /* everything went ok */
            result = 0;
         } else {
            /* we did not receive the correct answer */
            result = -1;
            if (debug)
               printf("\n");
         }

      } else {
         if (debug)
            printf("Read failed. Trying to reset GBA USB adapter\n");
         reset_gba(gba, debug);
      }
   }


   return(result);
}


int prepare_file(char *filename, u_int8_t **buffer, u_int32_t *len, u_int16_t *packets, int debug)
{
   FILE *infile;
   int  i;

   *len    = 0x40000;
   *buffer = (u_int8_t *)malloc(*len);

   infile = fopen(filename, "r");
   if (infile == NULL) {
      printf("Error while opening file '%s'\n", filename);
      return(1);
   }

   *len = fread((void *)*buffer, 1, *len, infile);
   fclose(infile);

   /* align length to 16 bytes */
   *len = (*len + 0x0F) & 0xFFFFFFF0;
   if (*len < 0x1c0)
      /* minimum length is 0x1c0 */
      *len = 0x1c0;

   *packets = (u_int16_t)(*len >> 6);
   if (*len & 0x3f)
      (*packets)++;

   /* overwrite the header */
   for (i = 0; i < 0xc0; i++)
      (*buffer)[i] = Header[i];

   return(0);
}
