
/*
 * $Id: ezusblib.h,v 1.2 2002/05/24 22:24:11 arnim Exp $
 */

int reset_gba(usb_dev_handle *, int);
