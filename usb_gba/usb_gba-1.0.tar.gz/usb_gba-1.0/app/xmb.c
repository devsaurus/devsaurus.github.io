/*
 *
 * Copyright (C) 2002, Arnim Laeuger
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version. See also the file COPYING which
 *  came with this application.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * $Id: xmb.c,v 1.3 2002/05/24 22:26:37 arnim Exp $
 *
 * $Log: xmb.c,v $
 * Revision 1.3  2002/05/24 22:26:37  arnim
 * finally interact with mblib and ezusblib
 * download to GBA now possible
 *
 * Revision 1.2  2002/05/23 21:17:40  arnim
 * make progress bar work with idle function
 *
 * Revision 1.1  2002/05/20 22:27:26  arnim
 * initial checkin
 *
 */

#include <stdio.h>
#include <sys/stat.h>

#include <gtk/gtk.h>

#include <usb.h>

#include "ezusblib.h"
#include "mblib.h"



static GtkWidget *fileName = NULL;
static GtkWidget *progressBar = NULL;
static GtkWidget *progressStart = NULL;
static gint idle_func_tag = 0;

static gint      stream_toggle;
static gint      result = 0;
static u_int32_t len, written;
static u_int8_t *buffer, command[16];
static u_int16_t packets;
static gint      debug = 0;
static usb_dev_handle *gba = NULL;


static void download_callback(u_int32_t len, u_int32_t written)
{
   gtk_progress_bar_update(GTK_PROGRESS_BAR(progressBar), (gfloat)written / (gfloat)len);
}


static void notify_ok(char *text)
{
   GtkWidget *dialog, *ok_button, *label;

   dialog    = gtk_dialog_new();

   gtk_window_set_title(GTK_WINDOW(dialog), "Notification");

   ok_button = gtk_button_new_with_label("Ok");
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->action_area),
                      ok_button, TRUE, TRUE, 0);
   gtk_signal_connect_object(GTK_OBJECT(ok_button), "clicked",
                             GTK_SIGNAL_FUNC(gtk_widget_destroy),
                             GTK_OBJECT(dialog));
   gtk_widget_show(ok_button);

   label = gtk_label_new(text);
   gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox),
                      label, TRUE, TRUE, 0);
   gtk_widget_show(label);

   gtk_window_set_focus(GTK_WINDOW(dialog), ok_button);
   gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);
   gtk_widget_show(dialog);
}

static void close_all_multiboot(void)
{
   if (buffer) {
      free(buffer);
      buffer = NULL;
   }
   if (gba) {
      usb_close(gba);
      gba = NULL;
   }
}

static gint idle_func(gpointer data)
{
   int i;

   result = write_stream_n(stream_toggle, gba, buffer, len, &written, result, debug);
   if (stream_toggle == 0)
      stream_toggle = 1;
   else
      stream_toggle = 0;

   if ((written >= len) || result < 0) {
      gtk_idle_remove(idle_func_tag);
      gtk_widget_set_sensitive(progressStart, TRUE);

      if (result >= 0) {
         result = usb_bulk_read(gba, 0x82, command, 0x06, 5000);
         if (debug)
            printf("Result of usb_bulk_read(): %d\n", result);
         if (result >= 0) {
            if (debug) {
               printf("  Received: %c%c: 0x%02x  ", command[0], command[1], command[1]);
               for (i = 0; i < 4; i++)
                  printf("0x%02x ", command[i+2]);
               printf("\n");
            }

            usb_release_interface(gba, 1);
         }
      } else {
         if (debug)
            printf("Write failed. Trying to reset GBA USB adapter\n");
         reset_gba(gba, debug);
      }

      close_all_multiboot();
   }

   return(TRUE);
}

static void callback_progress_start(GtkWidget *widget, GtkWidget *fileName)
{
   char *filename;
   struct stat stat_buf;

   filename = gtk_entry_get_text(GTK_ENTRY(fileName));

   if (stat(filename, &stat_buf) == 0) {
      result = prepare_file(filename, &buffer, &len, &packets, debug);

      gba = open_gba(0x06cd, 0xc002, debug);
      if (gba) {

         if (debug)
            printf("Opened GBA USB adapter\n");

         result = init_gba_transfer(gba, len, packets, debug);
         if (result >= 0) {
            write_stream_callback = download_callback;
            stream_toggle = 0;
            result        = 0;
            written       = 0;

            idle_func_tag = gtk_idle_add((GtkFunction)idle_func, NULL);
            gtk_widget_set_sensitive(progressStart, FALSE);
         } else {
            close_all_multiboot();
         }
      } else {
         printf("Cannot open gba_dev\n");
         close_all_multiboot();
      }

   } else {
      notify_ok(" File not found! ");
   }
}
static void callback_filesel_ok(GtkWidget *widget, GtkWidget *fileSel)
{
   if (fileName) {
      gtk_entry_set_text(GTK_ENTRY(fileName),
                         gtk_file_selection_get_filename(GTK_FILE_SELECTION(fileSel)));
   }
   /* close the file selector */
   gtk_widget_destroy(fileSel);

   /* reset the progress bar */
   gtk_progress_bar_update(GTK_PROGRESS_BAR(progressBar), 0.0);
}
static void callback_browse_button(GtkWidget *widget, gpointer data)
{
   GtkWidget *fileSel;

   fileSel = gtk_file_selection_new("Choose File");
   /* connect signals from the file selector's buttons */
   gtk_signal_connect(GTK_OBJECT(GTK_FILE_SELECTION(fileSel)->ok_button),
                      "clicked",
                      GTK_SIGNAL_FUNC(callback_filesel_ok), fileSel);
   gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(fileSel)->cancel_button),
                             "clicked",
                             GTK_SIGNAL_FUNC(gtk_widget_destroy), GTK_OBJECT(fileSel));

   gtk_window_set_modal(GTK_WINDOW(fileSel), TRUE);
   gtk_widget_show(fileSel);
}

static void free_list(GList *list)
{
   int n, i;
   GList *elem;

   n = g_list_length(list);
   for (i = 0; i < n; i++) {
      elem = g_list_nth(list, i);
      if (elem->data)
         free(elem->data);
   }

   g_list_free(list);
}

static GList *get_usb_dev_list(void)
{
   GList *list = NULL;
   struct usb_bus    *bus = NULL;
   struct usb_device *dev = NULL;
   char *elem_name;

   usb_init();
   usb_find_busses();
   usb_find_devices();

   for (bus = usb_busses; bus; bus = bus->next) {
      for (dev = bus->devices; dev; dev = dev->next) {
         elem_name = malloc(128 * sizeof(char));

         sprintf(elem_name, "%s %s (0x%04x 0x%04x)", bus->dirname, dev->filename,
                 dev->descriptor.idVendor,
                 dev->descriptor.idProduct);
         list = g_list_append(list, elem_name);
      }
   }

   return(list);
}


static void destroy_window(void)
{
   gtk_exit(0);
}

int main (int argc, char *argv[])
{
   GtkWidget *window;
   GtkWidget *vbox, *hbox;
   GtkWidget *fileLabel, *browseButton;
   GtkWidget *fileBox, *fileFrame;
   GtkWidget *usbBox, *usbFrame;
   GtkWidget *usbLabel, *usbDeviceSelector;
   GtkWidget *progressLabel;
   GtkWidget *progBox, *progLeft, *progRight;
   GList     *usbDevList;

   gtk_init (&argc, &argv);

   window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
   gtk_signal_connect (GTK_OBJECT(window), "destroy",
                       GTK_SIGNAL_FUNC(destroy_window), NULL);


   vbox = gtk_vbox_new(FALSE, 0);
   hbox = gtk_hbox_new(FALSE, 5);

   fileBox = gtk_hbox_new(FALSE, 0);
   /* build the file Label and Name widgets */
   fileLabel = gtk_label_new("Filename:");
   gtk_box_pack_start(GTK_BOX(fileBox), fileLabel, FALSE, FALSE, 4);
   gtk_widget_show(fileLabel);
   /**/
   fileName  = gtk_entry_new();
   gtk_box_pack_start(GTK_BOX(fileBox), fileName, TRUE, TRUE, 4);
   gtk_widget_show(fileName);
   /**/
   browseButton = gtk_button_new_with_label("Browse");
   gtk_box_pack_start(GTK_BOX(fileBox), browseButton, FALSE, FALSE, 4);
   gtk_signal_connect(GTK_OBJECT(browseButton), "clicked",
                      GTK_SIGNAL_FUNC(callback_browse_button), NULL); 
   gtk_widget_show(browseButton);
   /**/
   fileFrame = gtk_frame_new("File Settings");
   gtk_container_add(GTK_CONTAINER(fileFrame), fileBox);
   gtk_widget_show(fileBox);
   gtk_box_pack_start(GTK_BOX(hbox), fileFrame, TRUE, TRUE, 0);
   gtk_widget_show(fileFrame);


   /* the USB part */
   usbBox = gtk_hbox_new(FALSE, 0);
   usbLabel = gtk_label_new("USB device:");
   gtk_box_pack_start(GTK_BOX(usbBox), usbLabel, FALSE, FALSE, 4);
   gtk_widget_show(usbLabel);
   /**/
   usbDevList = get_usb_dev_list();
   usbDeviceSelector = gtk_combo_new();
   gtk_combo_set_popdown_strings(GTK_COMBO(usbDeviceSelector), usbDevList);
   gtk_combo_set_use_arrows_always(GTK_COMBO(usbDeviceSelector), 1);
   gtk_entry_set_editable(GTK_ENTRY(GTK_COMBO(usbDeviceSelector)->entry), FALSE);
   gtk_box_pack_start(GTK_BOX(usbBox), usbDeviceSelector, FALSE, FALSE, 4);
   gtk_widget_show(usbDeviceSelector);
   /**/
   usbFrame = gtk_frame_new("USB Settings");
   gtk_container_add(GTK_CONTAINER(usbFrame), usbBox);
   gtk_widget_show(usbBox);
   gtk_box_pack_end(GTK_BOX(hbox), usbFrame, FALSE, FALSE, 0);
   gtk_widget_show(usbFrame);

   /* finally pack the horizontal box */
   gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);

   /* the progress part */
   progressLabel = gtk_label_new("Download Progress");
   gtk_box_pack_start(GTK_BOX(vbox), progressLabel, FALSE, FALSE, 5);
   gtk_widget_show(progressLabel);
   /**/
   progressBar = gtk_progress_bar_new();
   gtk_progress_bar_set_orientation(GTK_PROGRESS_BAR(progressBar),
                                    GTK_PROGRESS_LEFT_TO_RIGHT);
   gtk_progress_bar_set_bar_style(GTK_PROGRESS_BAR(progressBar),
                                  GTK_PROGRESS_CONTINUOUS);
   gtk_progress_bar_update(GTK_PROGRESS_BAR(progressBar), 0);
   gtk_progress_set_format_string(GTK_PROGRESS(progressBar), "%p%%");
   gtk_progress_set_show_text(GTK_PROGRESS(progressBar), TRUE);
   gtk_box_pack_start(GTK_BOX(vbox), progressBar, FALSE, FALSE, 5);
   gtk_widget_show(progressBar);
   /**/
   progBox = gtk_hbox_new(FALSE, 0);
   progLeft = gtk_frame_new(NULL);
   gtk_frame_set_shadow_type(GTK_FRAME(progLeft), GTK_SHADOW_NONE);
   progRight = gtk_frame_new(NULL);
   gtk_frame_set_shadow_type(GTK_FRAME(progRight), GTK_SHADOW_NONE);
   gtk_box_pack_start(GTK_BOX(progBox), progLeft, TRUE, TRUE, 0);
   gtk_box_pack_end(GTK_BOX(progBox), progRight, TRUE, TRUE, 0);
   gtk_widget_show(progLeft);
   gtk_widget_show(progRight);
   /**/
   progressStart = gtk_button_new_with_label(" Start ");
   gtk_signal_connect(GTK_OBJECT(progressStart), "clicked",
                      GTK_SIGNAL_FUNC(callback_progress_start),
                      fileName);
   gtk_box_pack_start(GTK_BOX(progBox), progressStart, FALSE, FALSE, 0);
   gtk_widget_show(progressStart);
   /**/
   gtk_box_pack_start(GTK_BOX(vbox), progBox, FALSE, FALSE, 5);
   gtk_widget_show(progBox);

   gtk_container_add(GTK_CONTAINER(window), vbox);
   gtk_widget_show(hbox);
   gtk_widget_show(vbox);
   gtk_widget_show(window);

   gtk_main();

   free_list(usbDevList);

   return(0);
}
