/*
 *
 * Copyright (C) 2002, Arnim Laeuger
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version. See also the file COPYING which
 *  came with this application.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * $Id: mb.c,v 1.9 2002/05/24 22:24:41 arnim Exp $
 *
 * $Log: mb.c,v $
 * Revision 1.9  2002/05/24 22:24:41  arnim
 * replace a lot by prepare_file()
 *
 * Revision 1.8  2002/05/23 21:36:43  arnim
 * remove unused variables
 *
 * Revision 1.7  2002/05/12 21:57:37  arnim
 * move all multiboot related functionality into mblib
 *
 * Revision 1.6  2002/04/30 20:00:01  arnim
 * remove error message when un-resetting 8051
 *
 * Revision 1.5  2002/04/20 22:46:33  arnim
 * send data double streamed over OUT2 and OUT4 with pre-loading
 *
 * Revision 1.4  2002/04/17 21:33:48  arnim
 * add reset in case of read/write errors
 * may not work properly yet
 *
 * Revision 1.3  2002/04/17 19:09:54  arnim
 * fix
 *
 * Revision 1.2  2002/04/17 19:06:23  arnim
 * + cleanup
 * + add header
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>

#include <usb.h>

#include "mblib.h"
#include "ezusblib.h"


void print_written(u_int32_t len, u_int32_t written)
{
   printf("0x%06x\n", written);
}


int main(int argc, char *argv[])
{
   usb_dev_handle *gba = NULL;

   u_int8_t *buffer, command[16];
   u_int32_t len;
   u_int16_t packets;
   int       result;
   int       i;
   int       debug = 1;

   if (argc != 2) {
      printf("Usage: %s <filename>\n", argv[0]);
      return(1);
   }

   result = prepare_file(argv[1], &buffer, &len, &packets, debug);

   gba = open_gba(0x06cd, 0xc002, debug);
   if (gba) {
      if (debug)
         printf("Opened GBA USB adapter\n");

      result = init_gba_transfer(gba, len, packets, debug);
      if (result >= 0) {

         /* assign callback function */
         write_stream_callback = print_written;

         result = write_double_streamed(gba, buffer, len, debug);
         if (debug)
            printf("Result of write_double_streamed(): %d\n", result);
         if (result >= 0) {

            result = usb_bulk_read(gba, 0x82, command, 0x06, 5000);
            if (debug)
               printf("Result of usb_bulk_read(): %d\n", result);
            if (result >= 0) {
               if (debug) {
                  printf("  Received: %c%c: 0x%02x  ", command[0], command[1], command[1]);
                  for (i = 0; i < 4; i++)
                     printf("0x%02x ", command[i+2]);
                  printf("\n");
               }
              
               usb_release_interface(gba, 1);
            }
         } else {
            if (debug)
               printf("Write failed. Trying to reset GBA USB adapter\n");
            reset_gba(gba, debug);
         }
      }

      usb_close(gba);
   } else {
      printf("Cannot open gba_dev\n");
   }

   free(buffer);

   return(0);
}
