
/*
 * $Id: pagesize.h,v 1.2 2002/05/12 22:33:34 arnim Exp $
 */

/* max size of a page that is transferred continuously */
#define PAGESIZE 0x800
/* overlap value between consecutive pages */
#define OVERLAP 0x40

/* number of packets contained in a page */
#define TOGGLE_COUNT (PAGESIZE / 0x40)
