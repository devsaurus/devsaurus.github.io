/*
 *
 * Copyright (C) 2002, Arnim Laeuger
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version. See also the file COPYING which
 *  came with this application.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *
 * $Id: ezusblib.c,v 1.2 2002/05/24 22:23:55 arnim Exp $
 *
 * $Log: ezusblib.c,v $
 * Revision 1.2  2002/05/24 22:23:55  arnim
 * introduce debug variable
 *
 * Revision 1.1  2002/05/13 19:04:35  arnim
 * functions related to the EZ-USB device
 *
 */

#include <stdio.h>
#include <usb.h>

#include "ezusblib.h"


#define CPUCS 0x7f92


int reset_gba(usb_dev_handle *gba, int debug)
{
   int      result;
   u_int8_t command[8];

   usb_release_interface(gba, 1);

   /* put the 8051 into reset */
   command[0] = 0x01;
   result = usb_control_msg(gba, 0x40, 0xa0, CPUCS, 0, (char *)command, 1, 1000);
   if (result >= 0) {
      sleep(1);

      /* take the 8051 out of reset */
      command[0] = 0x00;
      result = usb_control_msg(gba, 0x40, 0xa0, CPUCS, 0, (char *)command, 1, 1000);
      if (result >= 0) {
         if (debug)
            printf("Reset successful.\n");
      }
//      else
//         printf("Un-reset of GBA USB adapter failed.\n");
      
   } else {
      if (debug)
         printf("Reset of GBA USB adapter failed.\n");
   }

   return(result);
}
