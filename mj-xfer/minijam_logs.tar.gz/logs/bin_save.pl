#!/usr/bin/perl -w

use strict;

my (@inarr, $elem);

while (<STDIN>) {
    @inarr = split;

    foreach $elem (@inarr) {
        print chr(hex($elem));
    }
}
