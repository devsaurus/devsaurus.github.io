#!/usr/bin/perl -w

use strict;

while (<STDIN>) {
    if (/^\d+\s+[\d.]+ +([0-9a-z]+):/) {
        if ($1 eq "0000") {
            FIRST: while (<STDIN>) {
                if (/^\d+\s+[\d.]+ +([0-9a-z]+ *){8}(.+)$/) {
                    print "$2\n";
                }
                last FIRST;
            }
        } else {
            NORM: while (<STDIN>) {
                if (/^\d+\s+[\d.]+ +(([0-9a-z]+ )*[0-9a-z]+)/) {
                    print "$1\n";
                }
                last NORM;
            }
        }
    }
}
